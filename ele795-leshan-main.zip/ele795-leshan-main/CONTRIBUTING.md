# Guide to contributing

If you plan to contribute to Leshan please take few minutes to read our [Contribution Guide](https://github.com/eclipse/leshan/wiki/How-to-contribute).

If you are confortable with **java**, **maven**, **git** and **github PR flow**,  you can just read the [legal stuff](https://github.com/eclipse/leshan/wiki/How-to-contribute#legal-stuff-) and our [code&design guidelines](https://github.com/eclipse/leshan/wiki/Code-&-design-guidelines).

Thanks a lot !